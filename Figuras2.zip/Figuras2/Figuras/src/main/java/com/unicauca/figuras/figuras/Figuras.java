/*
 */

package com.unicauca.figuras.figuras;

import com.unicauca.figuras.domain.models.presentetion.GUICirculo;
import com.unicauca.figuras.domain.models.presentetion.Menu;

/**
 *
 * @author ACER
 */
public class Figuras {

    public static void main(String[] args) {
    /*     GUICirculo guiCircle = new GUICirculo();
        guiCircle.setSize(400, 300);
        guiCircle.setVisible(true);
*/
        Menu menu = new Menu();
        menu.setSize(400, 300);
        menu.setVisible(true);
    }
    
}
