/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.unicauca.figuras.domain.models;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ACER
 */
public class CirculoTest {
    
    public CirculoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getRadio method, of class Circulo.
     */
    @Test
    public void testGetRadio() {
        System.out.println("getRadio");
        Circulo instance = new Circulo();
        double expResult = 0.0;
        double result = instance.getRadio();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRadio method, of class Circulo.
     */
    @Test
    public void testSetRadio() {
        System.out.println("setRadio");
        double radio = 0.0;
        Circulo instance = new Circulo();
        instance.setRadio(radio);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calcularArea method, of class Circulo.
     */
    @Test
    public void testCalcularArea() {
        System.out.println("calcularArea");
        Circulo instance = new Circulo(3);
        double expResult = Math.PI * Math.pow(3, 2);
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.01);
       
    }
    
     @Test
    public void testCalcularArea2() {
        System.out.println("calcularArea");
        Circulo instance = new Circulo(1);
        double expResult = 3.1416;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.01);
       
    }
    
     @Test
    public void testCalcularArea3() {
        System.out.println("calcularArea");
        Circulo instance = new Circulo(500000000);
        double expResult = Math.PI * Math.pow(500000000, 2);
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.01);
       
    }
    

    /**
     * Test of calcularPerimetro method, of class Circulo.
     */
    @Test
    public void testCalcularPerimetro() {
        System.out.println("calcularPerimetro");
        Circulo instance = new Circulo(1);
        double expResult = 6.28;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.01);
        
    }
    
      @Test
    public void testCalcularPerimetro2() {
        System.out.println("calcularPerimetro");
        Circulo instance = new Circulo(800000);
        double expResult = 5026548.25;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.01);
        
    }
    
      @Test
    public void testCalcularPerimetro3() {
        System.out.println("calcularPerimetro");
        Circulo instance = new Circulo(45);
        double expResult = 282.74;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.01);
        
    }
    
}
