/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.unicauca.figuras.domain.models;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ACER
 */
public class CuadradoTest {
    
    public CuadradoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calcularArea method, of class Cuadrado.
     */
    @Test
    public void testCalcularArea() {
        System.out.println("calcularArea");
        Cuadrado instance = new Cuadrado(2);
        double expResult = 4;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.02);
    }
    
     @Test
    public void testCalcularArea2() {
        System.out.println("calcularArea");
        Cuadrado instance = new Cuadrado(6000);
        double expResult = 600*600 ;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.02);
    }
    
      @Test
    public void testCalcularArea3() {
        System.out.println("calcularArea");
        Cuadrado instance = new Cuadrado(5000);
        double expResult = 5000*5000 ;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.02);
    }

    /**
     * Test of calcularPerimetro method, of class Cuadrado.
     */
    @Test
    public void testCalcularPerimetro() {
        System.out.println("calcularPerimetro");
        Cuadrado instance = new Cuadrado();
        double expResult = 0.0;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    
    
       @Test
    public void testCalcularPerimetro2() {
        System.out.println("calcularPerimetro");
        Cuadrado instance = new Cuadrado(6);
        double expResult = 36;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.02);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
       @Test
    public void testCalcularPerimetro3() {
        System.out.println("calcularPerimetro");
        Cuadrado instance = new Cuadrado(89);
        double expResult = 7921;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.02);
    }
    @Test
    public void testGetLado() {
        System.out.println("getLado");
        Cuadrado instance = new Cuadrado();
        double expResult = 0.0;
        double result = instance.getLado();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLado method, of class Cuadrado.
     */
    @Test
    public void testSetLado() {
        System.out.println("setLado");
        double lado = 0.0;
        Cuadrado instance = new Cuadrado();
        instance.setLado(lado);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
