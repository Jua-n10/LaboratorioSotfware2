/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.unicauca.figuras.domain.models;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author ACER
 */
public class TrianguloTest {
    
    public TrianguloTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of calcularArea method, of class Triangulo.
     */
    @Test
    public void testCalcularArea() {
        System.out.println("calcularArea");
        Triangulo instance = new Triangulo(12, 15, 16, 16);
        double expResult = (12 * 15)/2;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.001);
    }

    @Test
    public void testCalcularArea2() {
        System.out.println("calcularArea");
        Triangulo instance = new Triangulo(387, 234, 400, 400);
        double expResult = (387 * 234)/2;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.001);
    }
    
    @Test
    public void testCalcularArea3() {
        System.out.println("calcularArea");
        Triangulo instance = new Triangulo(4578,1234,2349,1123);
        double expResult = (4578*1234)/2;
        double result = instance.calcularArea();
        assertEquals(expResult, result, 0.1);
    }
    
    /**
     * Test of calcularPerimetro method, of class Triangulo.
     */
    @Test
    public void testCalcularPerimetro() {
        System.out.println("calcularPerimetro");
        Triangulo instance = new Triangulo(12, 15, 16, 16);
        double expResult = 12 + 16 + 16;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.01);
    }
    
    @Test
    public void testCalcularPerimetro2() {
        System.out.println("calcularPerimetro");
        Triangulo instance = new Triangulo(387, 234, 400, 400);
        double expResult = 387 + 400 + 400;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.01);
    }
    
    @Test
    public void testCalcularPerimetro3() {
        System.out.println("calcularPerimetro");
        Triangulo instance = new Triangulo(4578,1234,2349,1123);
        double expResult = 4578 + 2349 + 1123 ;
        double result = instance.calcularPerimetro();
        assertEquals(expResult, result, 0.01);
    }
    
    /**
     * Test of getLadoBase method, of class Triangulo.
     */
    @Test
    public void testGetLadoBase() {
        System.out.println("getLadoBase");
        Triangulo instance = new Triangulo();
        double expResult = 0.0;
        double result = instance.getLadoBase();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLadoBase method, of class Triangulo.
     */
    @Test
    public void testSetLadoBase() {
        System.out.println("setLadoBase");
        double lado = 0.0;
        Triangulo instance = new Triangulo();
        instance.setLadoBase(lado);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAltura method, of class Triangulo.
     */
    @Test
    public void testGetAltura() {
        System.out.println("getAltura");
        Triangulo instance = new Triangulo();
        double expResult = 0.0;
        double result = instance.getAltura();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setAltura method, of class Triangulo.
     */
    @Test
    public void testSetAltura() {
        System.out.println("setAltura");
        double altura = 0.0;
        Triangulo instance = new Triangulo();
        instance.setAltura(altura);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLado2 method, of class Triangulo.
     */
    @Test
    public void testGetLado2() {
        System.out.println("getLado2");
        Triangulo instance = new Triangulo();
        double expResult = 0.0;
        double result = instance.getLado2();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLado2 method, of class Triangulo.
     */
    @Test
    public void testSetLado2() {
        System.out.println("setLado2");
        double lado2 = 0.0;
        Triangulo instance = new Triangulo();
        instance.setLado2(lado2);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLado3 method, of class Triangulo.
     */
    @Test
    public void testGetLado3() {
        System.out.println("getLado3");
        Triangulo instance = new Triangulo();
        double expResult = 0.0;
        double result = instance.getLado3();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLado3 method, of class Triangulo.
     */
    @Test
    public void testSetLado3() {
        System.out.println("setLado3");
        double lado3 = 0.0;
        Triangulo instance = new Triangulo();
        instance.setLado3(lado3);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
